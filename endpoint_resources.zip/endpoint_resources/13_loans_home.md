# Loans Home — Credit Score, Eligibility, Active Loan

Covers `lib/features/loans/presentation/loans_screen.dart`.

The screen shows: credit-score gauge (hero), 4-stat grid ("How you're doing"), and either an **eligibility CTA** (no active loan) or an **outstanding-balance card** + repayment history (active loan).

## Endpoints

| Method | Path | Auth |
|--------|------|------|
| `GET` | `/me/credit` | Protected |
| `GET` | `/me/loans/active` | Protected |

`GET /me` (16) covers the stats grid (`jobs_completed`, `reliability_score`, `total_earned`, `joined_at`). Don't duplicate.

---

## `GET /me/credit`

Returns the worker's current credit score and the derived eligibility ceiling.

### Response 200

```json
{
  "credit_score": 76,
  "tier": "good",
  "subtitle": "Good — keep working to qualify for higher amounts.",
  "eligibility": {
    "is_eligible": true,
    "max_principal": 50000,
    "min_principal": 5000,
    "interest_rate_percent": 5.0,
    "repayment_percent_per_job_default": 0.20
  },
  "next_unlock": {
    "score_target": 80,
    "max_principal_at_target": 100000,
    "jobs_to_unlock_estimate": 2
  }
}
```

| Field | Type | Notes |
|-------|------|-------|
| `credit_score` | int | 0–100 |
| `tier` | enum | `building` (<40), `fair` (<60), `good` (<80), `excellent` (≥80). Mobile shows different copy per tier. |
| `subtitle` | string | Server-rendered status line under the gauge |
| `eligibility.is_eligible` | bool | True when `credit_score >= 60` |
| `eligibility.max_principal` | int | ₦. Server's table: 60→20k, 70→50k, 80→100k. Mobile must accept any ceiling — don't hard-code. |
| `eligibility.min_principal` | int | Floor for the slider in the apply screen |
| `eligibility.interest_rate_percent` | double | Rate that will be quoted on `/loans/apply` |
| `eligibility.repayment_percent_per_job_default` | double | 0.0–1.0. Default the slider in apply screen. |
| `next_unlock` | object \| null | Carrot for sub-eligible workers. `null` when `tier=excellent`. |

### Notes for backend

- Credit score is recalculated server-side after every clock-out. The mobile expects this endpoint to be live.
- `subtitle` is server-rendered so copy can be tuned without an app release. Keep ≤ 80 chars.
- Don't expose the underlying scoring features (jobs done, reliability weight, tenure). The mobile only needs the score + display copy.

---

## `GET /me/loans/active`

Returns the worker's active loan, or `null` if they have none.

### Response 200 (no active loan)

```json
{
  "loan": null
}
```

### Response 200 (active loan)

```json
{
  "loan": {
    "id": "loan_3c8a2f",
    "principal": 50000,
    "outstanding_balance": 32000,
    "interest_rate_percent": 5.0,
    "repayment_percent_per_job": 0.20,
    "disbursed_at": "2026-04-10T12:30:00Z",
    "status": "active",
    "next_repayment_estimate": 1000,
    "next_repayment_when": "On your next job",
    "repayments_count": 18,
    "repayments_total": 18000
  }
}
```

### Field shape (`Loan`)

Mirrors `lib/core/mock/models.dart` `Loan`, with these extras:

| Field | Type | Notes |
|-------|------|-------|
| `next_repayment_estimate` | int | ₦. Computed as `principal * repayment_percent_per_job` (the mobile already shows this). Server can override. |
| `next_repayment_when` | string | Human-readable. "On your next job" today; could become "On {date}" if scheduled repayment ships. |
| `repayments_count` | int | For the "% repaid" line |
| `repayments_total` | int | Sum of all `LoanRepayment.amount` so far |

### Loan status enum

Mirrors mobile's `LoanStatus`:

| Wire | Display |
|------|---------|
| `none` | (Should never appear in this endpoint — `loan` is `null` instead) |
| `pending` | Pending review |
| `approved` | Approved |
| `rejected` | Rejected |
| `active` | Active |
| `repaid` | Repaid |

### Notes for backend

- The detail page `15_loan_detail.md` carries the full `repayments` array. This endpoint deliberately doesn't — it's only the at-a-glance card on the loans home.
- Statuses `pending`, `approved`, `active` all return a non-null `loan`. Mobile branches on `status` for the right UI:
  - `pending` → "Reviewing your application" copy
  - `approved` → "Funds disbursing" copy
  - `active` → outstanding card + repayment list
